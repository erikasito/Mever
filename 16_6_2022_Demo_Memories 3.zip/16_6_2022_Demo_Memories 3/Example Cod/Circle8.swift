//
//  Circle7.swift
//  Demo_Memories
//
//  Created by Erika Sito on 12/06/22.
//

//import SwiftUI
//
//struct Circle8: View {
//    
//    
//
//    var body: some View {
//        
//         
//        
//        NavigationView{ // Add the NavigationView
//          
//            ZStack{
//                
//                Color(UIColor(named: "BackgroundColor")!)
//                                   .edgesIgnoringSafeArea(.all)
//            ZStack{
//
//                Circle3()
//                    .offset(x: 0, y: -70)
//                
//               
//
//              
//                
//               
//                
//                ForEach(ImageEnum2.allCases, id:\.self) { imageEnum2 in // Itterate over all enum cases
//                    NavigationLink(destination: imageEnum2.detailView){ // get detailview here
//                        
//                        
//                        ZStack{
//                        Image("Image1")// get image assset name here
//
//                            .resizable()
//                            .aspectRatio(contentMode: .fit)
//                            .padding()
//                            .scaledToFit()
//                        
//                        
//                        Text("Adult")
//                            .foregroundColor(Color("Text1"))
//                            .fontWeight(.bold)
//                            
//                            
//                    }
//                            .position(x: 585, y: -150)
//                            .frame(width: 160.0, height: 160.0)
//                        
//                        ZStack{
//                        Image("Image2")// get image assset name here
//
//                            .resizable()
//                            .aspectRatio(contentMode: .fit)
//                            .padding()
//                            .scaledToFit()
//                            
//                            
//                            Text("Midlife")
//                                .foregroundColor(Color("Text1"))
//                                .fontWeight(.bold)
//                                .multilineTextAlignment(.center)
//                                
//                        }
//                            .position(x: 530, y: -100)
//                            .frame(width: 160.0, height: 160.0)
//                      
//                        ZStack{
//                        Image("Image3")// get image assset name here
//
//                            .resizable()
//                            .aspectRatio(contentMode: .fit)
//                            .padding()
//                            .scaledToFit()
//                   
//                            Text("Seniority")
//                                .foregroundColor(Color("Text1"))
//                                .fontWeight(.bold)
//                               
//                        }
//                            .position(x: 395, y: 0)
//                            .frame(width: 160.0, height: 160.0)
//                      
//                        ZStack{
//                        Image("Image4")// get image assset name here
//
//                            .resizable()
//                            .aspectRatio(contentMode: .fit)
//                            .padding()
//                            .scaledToFit()
//                            
//                            
//                            Text("???")
//                                .foregroundColor(Color("Text1"))
//                                .fontWeight(.bold)
//                               
//
//                        }
//                            .position(x: 220, y: 100)
//                            .frame(width: 160.0, height: 160.0)
//                        
//                        ZStack{
//                        Image("Image6")// get image assset name here
//
//                            .resizable()
//                            .aspectRatio(contentMode: .fit)
//                            .padding()
//                            .scaledToFit()
//                            
//                         
//                            Text("Childhood")
//                                .foregroundColor(Color("Text1"))
//                                .fontWeight(.bold)
//                             
//
//                        }
//                            .position(x: -190, y: -100)
//                            .frame(width: 160.0, height: 160.0)
////
//                        ZStack{
//                        Image("Image5")// get image assset name here
//
//                            .resizable()
//                            .aspectRatio(contentMode: .fit)
//                            .padding()
//                            .scaledToFit()
//                            
//                            
//                            Text("Teenage")
//                                .foregroundColor(Color("Text1"))
//                                .fontWeight(.bold)
//                               
//                        }
//                            .position(x: -400, y: 0)
//                            .frame(width: 160.0, height: 160.0)
////
//                        ZStack{
//                        Image("Image7")// get image assset name here
//
//                            .resizable()
//                            .aspectRatio(contentMode: .fit)
//                            .padding()
//                            .scaledToFit()
//                            
//                            
//                            Text("Birth")
//                                .foregroundColor(Color("Text1"))
//                                .fontWeight(.bold)
//                               
//                        }
//                            .position(x: -555, y:100)
//                            .frame(width: 160.0, height: 160.0)
////
//                    }
//                }
//                    
//            }
////            .offset(y: -10)
//            }
//           
//
//            
//            }
//
//    
//    
//
//    }
//}
//
//struct Circle8_Previews: PreviewProvider {
//    static var previews: some View {
//        Circle8()
//    }
//}
