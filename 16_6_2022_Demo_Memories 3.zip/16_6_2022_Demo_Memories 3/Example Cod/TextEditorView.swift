//
//  TextEditorView.swift
//  Demo_Memories
//
//  Created by Erika Sito on 03/06/22.
//

//import SwiftUI
//
//struct TextEditorView: View {
//    
//    @AppStorage("name_surname") private var text1 = "Name - Surname"
////        @State var text1: String = "Name - Surname"
////        @State var text2: String = "Enter Text Here"
////        @State var text3: String = "Enter Text Here"
//
//        
//        var body: some View {
//            
//            Form {
//                Group {
//                    HStack(alignment: .center) {
//                        
//                        Spacer(minLength: 8)
////                        Text("Name - Surname")
//                        TextEditor(text: $text1)
//                            .foregroundColor(Color(.systemGray))
//                           
////                        TextField("Name - Surname", text: $text1)
////                            .padding(.all, 10)
////                            .background(Color(.systemGray6))
////                            .cornerRadius(8)
//                        
//                    }
////                    VStack(alignment: .leading) {
////                        Spacer(minLength: 8)
////                        Text("Comment 2:")
////                        TextEditor(text: $text2)
////                            .padding(.all, 1.0)
////                    }
////                    VStack(alignment: .leading) {
////                        Spacer(minLength: 8)
////                        Text("Comment 3:")
////                        TextEditor(text: $text3)
////                            .padding(.all, 1.0)
////                    }
//                }
//                .padding(10)
//                .background(Color(UIColor(named: "BackgroundColor")!))
//                .cornerRadius(20)
//            }
//                        
//        }
//    }
//        
//
//struct TextEditorView_Previews: PreviewProvider {
//    static var previews: some View {
//        TextEditorView()
//    }
//}
//
