//
//  AllCircle.swift
//  Memories
//
//  Created by Erika Sito on 30/05/22.
//

//import SwiftUI
//
//struct AllCircle: View {
    
//    @AppStorage("name_surname") private var text1 = "Name - Surname"
    
//    var body: some View {
//
//
//
//        ZStack{
//
//
//            Circle8()
//
//
//
//
//        VStack{

//            CircleImage(image: Image("Erika"))

               
            

//            HStack{
//                Rectangle()
//                .fill(Color(UIColor(named: "BackgroundColor")!))
//                    .frame(width:420, height: 70)
//
//                    .overlay(
//                        TextField("Name - Surname", text: $text1)
//                                                  .padding(.all, 10)
//
//                                                  .cornerRadius(8)
//
//                                                  .foregroundColor(Color(.systemGray))
//                    )
//            
//            
//
//            }.multilineTextAlignment(.center)
//                .font(.largeTitle)
//                .offset(x: 0, y: 53)

                
//        }
//
//            
//            
//
//        }
//        .offset(x: 0, y: -20)
//      
//      
//    }
//  
//}
//
//struct AllCircle_Previews: PreviewProvider {
//    static var previews: some View {
//        AllCircle()
//    }
//}
