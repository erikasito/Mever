//
//import SwiftUI
//
//struct Cloud: View {
//
//    var cloudphoto: CloudPhoto
//
//    @State  var showCloud = false
//
//    var body: some View {
//        ZStack{
//            Color(UIColor(named: "BackgroundColor")!)
//                .edgesIgnoringSafeArea(.all)
//
//
//
//            Button(action: {
//                showCloud = true
//            }) {
//        VStack{
//
//
//            Image(cloudphoto.imageName)
//                .resizable()
//                .scaledToFill()
////                .navigationTitle(cloudphoto.title)
//                .frame(width: 250, height: 250)
//                .offset(x:0, y:100)
//
//
//        }
//
//                }
//            }
//
//
//        }
//
//
//
//}
//
//
//
//
//
//struct Cloud_Previews: PreviewProvider {
//    static var previews: some View {
//        Cloud(cloudphoto: CloudPhoto(id: 0, imageName: "cloud")
//        )
//    }
//}
