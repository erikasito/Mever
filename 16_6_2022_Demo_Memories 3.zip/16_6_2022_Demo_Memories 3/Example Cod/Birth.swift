////
////  Birth.swift
////  Demo_Memories
////
////  Created by Erika Sito on 07/06/22.
////
//
//import SwiftUI
//
//struct Birth: View {
//    
//    //    let items = Array(1...6).map({ "image\($0)"})
//    let items = Array(1...6).map({ "image\($0)"})
//    let layout = [
//        
//        GridItem(.flexible(minimum: 100)),
//        GridItem(.flexible(minimum: 100)),
//        GridItem(.flexible(minimum: 100))
//        
//    ]
//    @State private var showingSheet = false
//    
//    var body: some View {
//        NavigationView{
//            ScrollView(.horizontal) {
//                LazyVGrid(columns: layout, content:  {
//                    ForEach(items, id: \.self) {
//                        item in
//                        VStack{
//                            Image(item)
//                                .resizable()
//                                .aspectRatio(contentMode: .fit)
//                                .padding()
//                                .scaledToFit()
//                                .frame(width: 400.0, height: 400.0)
//                                .onTapGesture {
//                                    showingSheet.toggle()
//                                }
//                            
////                                .offset(x: -135, y: 205)
////
//                            
//                            //                                Spacer()
//                            //
//                            //                            Button("GET"){
//                            //
//                            //                            }.foregroundColor(Color(UIColor(named: "BackgroundColor3")!))
//                            //                                .padding()
//                            //                                Spacer()
//                            
//                            
//                            
//                            //                            }
//                            
//                        }
//                    }
//                    
//                })
//                
//            }
//            .navigationTitle("Moments")
//        }
//    }
//}
//struct Birth_Previews: PreviewProvider {
//    static var previews: some View {
//        Birth()
//    }
//}
