//
//  MessageModel.swift
//  Demo_Memories
//
//  Created by Erika Sito on 01/06/22.
//


import SwiftUI



struct Message: Identifiable {

    var id : Int
    var title: String
    var imageName : String

}


var aboutmessage = [Message(id: 0, title: "Dreams", imageName: "0"),




                      Message(id: 1, title: "Goals", imageName: "1"),

                    Message(id:2, title: "Life Lessons", imageName: "2"),

                    Message(id:3, title: "Story", imageName: "3")

                        ]




struct TextMessage: Identifiable {

    var id : Int
    var description: String


}


var abouttextmessage = [TextMessage(id: 0, description: "My dream is to fly, Over the rainbow, so high!"),

                        TextMessage(id: 1, description: "Become a Super-Heroine!"),
                        
                        TextMessage(id: 2, description: "Good... Yes, Stupid... NO!"),

                        TextMessage(id: 2, description: "One, none, one hundred thousand!")

                        ]



struct TextGalleryBirth: Identifiable {

    var id : Int
    var title: String
    var description: String


}


var abouttextgallerybirth = [TextGalleryBirth(id: 0, title: "Moments", description: "Add the most memorable events you experienced with your family and friends in this face of your life."),

]


struct CloudPhoto: Identifiable {

    var id : Int
    var imageName : String

}

var cloudphoto = [CloudPhoto(id: 0, imageName: "cloud")


                        ]
