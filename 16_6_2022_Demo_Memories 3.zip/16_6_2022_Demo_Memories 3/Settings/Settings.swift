//
//  AddPicture.swift
//  Demo_Memories
//
//  Created by Francesco Amirante on 07/06/22.
//

import SwiftUI

struct SettingsView: View {
    
    init(){
        UITableView.appearance().backgroundColor = UIColor(Color.clear)
    }
    
    @State var data = ["abc", "def"]
    
    
    var body: some View {
        
        ZStack{
            Color(UIColor(named: "BackgroundColor")!)
                               .edgesIgnoringSafeArea(.all)
            
            List {
                Section(header: Text("Make your memories eternal")){
                NavigationLink("Future Admin", destination: FutureAdmin())
                }
                
               
            .navigationTitle("Settings")
        }
//            .background(Color(UIColor(named: "BackgroundColor")!))
                .ignoresSafeArea()
                .offset(x: 0, y: 10)
    }
}
}

struct SettingsView_Previews: PreviewProvider {
    static var previews: some View {
        SettingsView()
    }
}
