//
//  alert.swift
//  Demo_Memories
//
//  Created by Francesco Amirante on 07/06/22.
//

import SwiftUI

struct alertView: View {
    @State private var showingAlert = false

    var body: some View {
        Button("Continue") {
            showingAlert = true
        }
        .alert(isPresented: $showingAlert) {
            Alert(title: Text("Memory app would like to access your personal data"), message: Text("Name, Surname, Birth date and pictures will be stored on your iCloud and not shared with third parties  "), primaryButton: .default(Text("Don't allow")), secondaryButton: .default(Text("Ok")
                                                                                                                                                                                                                                                                                            .fontWeight(.black)))
        }
        
            
        }
    }

struct alert_Previews: PreviewProvider {
    static var previews: some View {
        alertView()
    }
}
