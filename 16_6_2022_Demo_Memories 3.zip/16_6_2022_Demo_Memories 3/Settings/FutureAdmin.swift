//
//  FutureAdmin.swift
//  Demo_Memories
//
//  Created by Francesco Amirante on 07/06/22.
//

import SwiftUI

struct FutureAdmin: View {
    var body: some View {
        
        ZStack{
            Color(UIColor(named: "BackgroundColor")!)
             .edgesIgnoringSafeArea(.all)
        ZStack{
            
            RoundedRectangle(cornerRadius: 25)
                        .fill(Color(UIColor(named: "BackgroundColor2")!))
                        .frame(width: 390, height: 500)
                        .position(x: 207, y: 270)
            
            Image(systemName: "infinity.circle.fill")
                .font(.system(size: 100))
                .foregroundColor(.white)
                .position(x: 207, y: 90)
                }
            Text("Make your memories eternal")
                .font(.title2)
                .fontWeight(.bold)
                .position(x: 207, y: 165)
            
            Text("You can choose a person who after your death will be responsible for sharing your memories with the people who helped collect them.")
                .font(.caption)
                .fontWeight(.light)
                .multilineTextAlignment(.center)
                .padding(.horizontal, 10.0)
                .position(x: 170, y: 220)
                .frame(width: 350)
                
}.navigationTitle("Future Admin")
        
}
}
struct FutureAdmin_Previews: PreviewProvider {
    static var previews: some View {
        FutureAdmin()
    }
}
