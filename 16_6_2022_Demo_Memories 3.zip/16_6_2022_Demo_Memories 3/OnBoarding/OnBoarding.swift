//
//  OnBoarding.swift
//  Demo_Memories
//
//  Created by Erika Sito on 15/06/22.
//

        import SwiftUI

        struct onBoardingStep {
            
            let image: String
            let text1: String
            let text2: String
        }

        private let onBoardingSteps = [

            onBoardingStep(image: "1on", text1: "COLLECT MOMENTS", text2: "Select the most important memories by period of your life."),
            onBoardingStep(image: "2on", text1: "MERGE MEMORIES", text2: "Associate each photo with a memory of yours or of the people who lived that moment with you."),
            onBoardingStep(image: "3on", text1: "BE ETERNAL", text2: "Choose a future admin who, after your death, will share your profile with all those who have accompanied you in your journey. ")
        ]


            
        struct onBoardingOk: View {
            
            @AppStorage("onboarding") var onboarding = true
            @State private var currentStep = 0
            @Binding var closeOnboarding : Bool
            
        //    init() {
        //        UIScrollView.appearance().bounces = false
        //    }
            var body: some View {
                    ZStack{
                Color(UIColor(named: "BackgroundColor")!)
                                   .edgesIgnoringSafeArea(.all)
                
                VStack{
          TabView(selection: $currentStep){
                        ForEach(0..<onBoardingSteps.count) { it in
                            
                            ZStack{
                                Image(onBoardingSteps[it].image)
                                    .resizable()
                                    .scaledToFill()
                                    .frame(width: 400, height: 400)
                                    .offset(x: 0, y: 100)
                                   
                                Text(onBoardingSteps[it].text1)
                                    .foregroundColor(Color(UIColor(named: "Text1")!))
                                    .fontWeight(.black)
                                    .offset(x: 0, y: 198)
                               
                                Text(onBoardingSteps[it].text2)
                                    .foregroundColor(Color(UIColor(named: "Text1")!))
                                    .fontWeight(.semibold)
                         
                                    .frame(width: 280, height: 230)
                                    .offset(x: 0, y: 255)
                            }
        //                    .tag(it)
        
                        }
                    }
                    .tabViewStyle(PageTabViewStyle(indexDisplayMode: .never))
                    
                    HStack{
                    ForEach(0..<onBoardingSteps.count) { it in
                        
                        if it == currentStep {
                            Rectangle()
                                .frame(width: 20, height: 10)
                                .cornerRadius(10)
                                .foregroundColor(Color(UIColor(named: "BackgroundColor3")!))
                        } else {
                            Circle()
                                .frame(width: 10, height: 10)
                                .foregroundColor(Color(UIColor(named: "BackgroundColor2")!))
                    }
                    }
                    }
                    .padding(.bottom, 24)
                    
                    
                    Button(action: {
                        
                        onboarding = false
                        
                        if self.currentStep < onBoardingSteps.count - 1 {
                            self.currentStep += 1
                            
                        } else {
                            closeOnboarding.toggle()
                               

                        }
                        
                        
                    }) {
                        Text(currentStep < onBoardingSteps.count - 1 ? "Next" : "Get started")
                            .padding(16)
                            .frame(maxWidth: .infinity)
                            .background(Color(UIColor(named: "BackgroundColor3")!))
                            .cornerRadius(16)
                            .padding(.horizontal, 16)
                            .foregroundColor(.white)
                    }
                    .buttonStyle(PlainButtonStyle())
                   
                    
                   
                    
                }
                    
                
                        
        //                NavigationLink(destination: Carousel()) {
        //                    Button(action: {
        //
        //                    if self.currentStep < onBoardingSteps.count  {
        //                        self.currentStep -= 1
        //
        //                    }
        //
        //
        //                    else {
        //
        //                    }
        //
        //
        //                }) {
        //
        //                    Text(currentStep < onBoardingSteps.count - 2 ? "< Back" : "< Back")
        //                        .padding(16)
        //                        .frame(width: 120, height: 30)
        //                        .position(x: 50, y: 30)
        //                        .foregroundColor(Color(UIColor(named: "BackgroundColor3")!))
        //                }
        //                .buttonStyle(PlainButtonStyle())
        //                .disabled(currentStep < onBoardingSteps.count - 2)
        //                }
                        
                        Button(action: {
                            
                            onboarding = false
                            
                        if self.currentStep < onBoardingSteps.count  {
                            self.currentStep -= 1

                        }


                        else {
                        }


                    }) {

                        Text(currentStep < onBoardingSteps.count - 2 ? "< Back" : "< Back")
                            .fontWeight(.bold)
                            .padding(16)
                            .frame(width: 120, height: 30)
                            .position(x: 50, y: 30)
                            .foregroundColor(Color(UIColor(named: "Text1")!))
                            
                    }
                    .buttonStyle(PlainButtonStyle())
                    .disabled(currentStep < onBoardingSteps.count - 2)
                        
                        
                        
                        VStack{
                        Text("MEVER")
                            .font(.system(size: 80))
                            .fontWeight(.black)
                            .foregroundColor(Color("BackgroundColor3"))
                            .position(x: 200, y: 112)
                            Text("Be Remembered. Forever.")
                                .font(.system(size: 20))
                            .font(.caption)
                            .fontWeight(.semibold)
                            .foregroundColor(Color("BackgroundColor3"))
                            .position(x: 200, y: -248)
                            
                              
                            
            }
                        
                        
                        
        }
            }
        }
        struct onBoardingOk_Previews: PreviewProvider {
            @State static  var close = false
            static var previews: some View {
                onBoardingOk(closeOnboarding: $close)
            }
        }








