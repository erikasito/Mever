//
//  Cloud1.swift
//  Demo_Memories
//
//  Created by Erika Sito on 08/06/22.
//

import SwiftUI

struct Cloud1: View {
   
        var body: some View{
            Image("Erika")
        }
    }

 

struct Cloud1_Previews: PreviewProvider {
    static var previews: some View {
        Cloud1()
    }
}
