//
//  Cloud2.swift
//  Demo_Memories
//
//  Created by Erika Sito on 08/06/22.
//

import SwiftUI

struct Cloud2: View {
   
        var body: some View{
            Text("test2")
        }
    }

struct Cloud2_Previews: PreviewProvider {
    static var previews: some View {
        Cloud2()
    }
}
