//
//  ImageEnum.swift
//  Demo_Memories
//
//  Created by Erika Sito on 08/06/22.
//

import Foundation
import SwiftUI

enum ImageEnum: String, CaseIterable{ //Please find a better name ;)
    case cloud1, cloud2, cloud3, cloud4, cloud5, cloud6
    
    var imageName: String{ // get the assetname of the image
        switch self{
        case .cloud1:
            return "Erika"
        case .cloud2:
            return "test2"
        case .cloud3:
            return "test2"
        case .cloud4:
            return "test2"
        case .cloud5:
            return "test2"
        case .cloud6:
            return "test2"
        }
    }
    
    @ViewBuilder
    var detailView: some View{ // create the view here, if you need to add
        switch self{           // paramaters use a function or associated
        case .cloud1:          // values for your enum cases
            Cloud1()
        case .cloud2:
            Cloud2()
        case .cloud3:
            Cloud2()
        case .cloud4:
            Cloud2()
        case .cloud5:
            Cloud2()
        case .cloud6:
            Cloud2()
        }
    }
}


enum ImageEnum2: String, CaseIterable{ //Please find a better name ;)
    case image1, image2, image3, image4, image5, image6, image7

    
    @ViewBuilder
    var detailView: some View{ // create the view here, if you need to add
        switch self{           // paramaters use a function or associated
        case .image1:          // values for your enum cases
        GridBirth()
        case .image2:
        GridBirth()
        case .image3:
       GridBirth()
        case .image4:
        GridBirth()
        case .image5:
         GridBirth()
        case .image6:
        GridBirth()
        case .image7:
          GridBirth()
        }
    }
}


