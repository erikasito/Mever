//
//  Grid.swift
//  Demo_Memories
//
//  Created by Erika Sito on 08/06/22.
//

import SwiftUI
import Foundation

    struct GridBirth: View {
        
        
        var columnGrid: [GridItem] = [GridItem(.flexible(minimum: 100), spacing: 40), GridItem(.flexible(minimum: 100), spacing: 40), GridItem(.flexible(minimum: 100), spacing: 40)]
       
        @State var gamePlay6 = false
    
        var body: some View {
            
         
                
            
            NavigationView{ // Add the NavigationView
              
                ZStack{
                    
                    Color(UIColor(named: "BackgroundColor")!)
                                       .edgesIgnoringSafeArea(.all)
                VStack{
            
                    Text("Birth:")
                        .font(.largeTitle)
                        .foregroundColor(Color(UIColor(named: "Text1")!))
                        .fontWeight(.black)
                        .multilineTextAlignment(.leading)
                        .offset(x: -140, y: -195)
                    
                    Text("Moments")
                        .font(.largeTitle)
                        .foregroundColor(Color(UIColor(named: "Text1")!))
                        .fontWeight(.bold)
                        .multilineTextAlignment(.leading)
                        .offset(x: -115, y: -190)
                       
                       
                    Text("Add the most memorable moments you experienced with your family and friends in this phase of your life.")
                        .foregroundColor(Color(UIColor(named: "Text1")!))
                        .fontWeight(.regular)
                        .multilineTextAlignment(.leading)
                        .offset(x: 0, y: -215)
                        .frame(width: 380, height: 80, alignment: .leading)
                        
                
                ScrollView(.horizontal) {
                LazyVGrid(columns: columnGrid, spacing: 0, pinnedViews: []) {
                    ForEach(ImageEnum.allCases, id:\.self) { imageEnum in // Itterate over all enum cases
                        NavigationLink(destination: imageEnum.detailView){ // get detailview here
                            Image("Image-1")// get image assset name here

                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .padding()
                                .scaledToFit()
                                .frame(width: 150.0, height: 150.0)
                                .offset(x:15, y: -10)
                            
                             
                        }
                        }
                }
                }
               
//                .navigationTitle("Moments")
                .offset(x: 0, y: -235)
                }
                    VStack{
                    Text("Meaningful")
                        .font(.largeTitle)
                        .foregroundColor(Color(UIColor(named: "Text1")!))
                        .fontWeight(.bold)
                        .multilineTextAlignment(.leading)
                        .offset(x: -100, y: 210)
                       
                       
                    Text("Add an object, a song, a person, a place and wathever has been meaningful for you, in this phase of your life.")
                        .foregroundColor(Color(UIColor(named: "Text1")!))
                        .fontWeight(.regular)
                        .multilineTextAlignment(.leading)
                        .offset(x: 5, y: 185)
                        .frame(width: 380, height: 80, alignment: .leading)
                        
                    ScrollView(.horizontal) {
                    LazyVGrid(columns: columnGrid, spacing: 0, pinnedViews: []) {
                        ForEach(ImageEnum.allCases, id:\.self) { imageEnum in // Itterate over all enum cases
                            NavigationLink(destination: imageEnum.detailView){ // get detailview here
                                Image("Image-1")// get image assset name here

                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .padding()
                                    .scaledToFit()
                                    .frame(width: 150.0, height: 150.0)
                                    .offset(x:15)
                                
                            }
                            }
                        }
                    }
                   
//                    .navigationTitle("Meaningful")
                    
                    .offset(x: 0, y: 155)
                    
                    
                    
                    
                    
                }.offset(x: 0, y: 5)
              
                    
                }
        }
    }
    }
struct GridBirth_Previews: PreviewProvider {
    static var previews: some View {
        GridBirth()
    }
}




//                                imageEnum.imageName)
