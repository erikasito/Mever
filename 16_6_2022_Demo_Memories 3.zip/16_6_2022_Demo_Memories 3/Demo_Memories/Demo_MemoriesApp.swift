//
//  Demo_MemoriesApp.swift
//  Demo_Memories
//
//  Created by Erika Sito on 01/06/22.
//

import SwiftUI

@main
struct Demo_MemoriesApp: App {
    let persistenceController = PersistenceController.shared
    @State static  var close = false
    var body: some Scene {
        WindowGroup {
           
            Main(close: Demo_MemoriesApp.$close)
                .environment(\.managedObjectContext, persistenceController.container.viewContext)
        }
    }
}
