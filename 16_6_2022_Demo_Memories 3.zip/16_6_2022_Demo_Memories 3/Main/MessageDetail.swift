//
//  MessageDetail.swift
//  Memories
//
//  Created by Erika Sito on 31/05/22.
//

import SwiftUI

struct MessageDetail: View {
    
    let message: Message
    let textmessage: TextMessage
    
    var body: some View {
        ZStack{
            Color(UIColor(named: "BackgroundColor4")!)
                .edgesIgnoringSafeArea(.all)
            
            
            ScrollView(.vertical, showsIndicators: false) {
            
        VStack{


            Image(message.imageName)
                .resizable()
                .scaledToFill()
                .navigationTitle(message.title)
                .frame(width: 250, height: 250)
                .offset(x:0, y:100)




            Text(textmessage.description)
                .frame(width: 450, height: 50)
                .offset(x: 0, y: 150)
                .font(.system(size: 18, weight: .semibold))
                .padding()
            
       

                    }
                }
            }
            

        }

        
  
      
                
            }
        
        
    
struct MessageDetail_Previews: PreviewProvider {
    static var previews: some View {
        MessageDetail(message: Message(id: 0, title: "Dreams", imageName: "0")
                      ,
                      textmessage: TextMessage(id: 0, description: "My dream is to fly, Over the rainbow, so high!")
        )
    }
}
