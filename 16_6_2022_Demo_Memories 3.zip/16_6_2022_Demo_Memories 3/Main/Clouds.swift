//
//  Prova2.swift
//  Demo_Memories
//
//  Created by Erika Sito on 14/06/22.
//

import SwiftUI

struct Clouds: View {
     
    @Binding var gamePlay: Bool
    @Binding var gamePlay1: Bool
    @Binding var gamePlay2: Bool
    @Binding var gamePlay3: Bool
    @Binding var gamePlay4: Bool
    @Binding var gamePlay5: Bool
    @Binding var gamePlay6: Bool
    
            var body: some View {
                
             
                  
                    ZStack{
   
                    ZStack{


                        
                            
                                ZStack{
                                Image("Image1")// get image assset name here

                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .padding()
                                    .scaledToFit()
                                
                                
                                Text("Adult")
                                    .foregroundColor(Color("Text1"))
                                    .fontWeight(.black)
                                    
                                    
                            }
//                                    .position(x: 80, y: -150)
                                .offset(x: 0, y: -230)
                                    .frame(width: 160.0, height: 160.0)
                                    .onTapGesture {
                                        self.gamePlay.toggle()
                                    }
                                     .sheet(isPresented: $gamePlay){
                                        GridAdult()}
                                
                        
                                
                                ZStack{
                                Image("Image2")// get image assset name here

                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .padding()
                                    .scaledToFit()
                                    
                                    
                                    Text("Midlife")
                                        .foregroundColor(Color("Text1"))
                                        .fontWeight(.black)
                                        .multilineTextAlignment(.center)
                                        
                                }
//                                    .position(x: 205, y: -110)
                                .offset(x: 120, y: -190)
                                    .frame(width: 160.0, height: 160.0)
                                    .onTapGesture {
                                        self.gamePlay1.toggle()
                                    }
                                     .sheet(isPresented: $gamePlay1){
                                        GridMidlife()}
                              
                                ZStack{
                                Image("Image3")// get image assset name here

                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .padding()
                                    .scaledToFit()
                           
                                    Text("Seniority")
                                        .foregroundColor(Color("Text1"))
                                        .fontWeight(.black)
                                       
                                }
//                                    .position(x: 225, y: -5)
                                .offset(x: 145, y: -85)
                                    .frame(width: 160.0, height: 160.0)
                                    .onTapGesture {
                                        self.gamePlay2.toggle()
                                    }
                                     .sheet(isPresented: $gamePlay2){
                                        GridSeniority()}
                        
                                ZStack{
                                Image("Image4")// get image assset name here

                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .padding()
                                    .scaledToFit()
                                    
                                    
                                    Text("???")
                                        .foregroundColor(Color("Text1"))
                                        .fontWeight(.black)
                                       

                                }
//                                    .position(x: 210, y: 100)
                                .offset(x: 125, y: 20)
                                    .frame(width: 160.0, height: 160.0)
                                    .onTapGesture {
                                        self.gamePlay3.toggle()
                                    }
                                     .sheet(isPresented: $gamePlay3){
                                        Grid()}
                        
                                
                                ZStack{
                                Image("Image6")// get image assset name here

                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .padding()
                                    .scaledToFit()
                                    
                                 
                                    Text("Childhood")
                                        .foregroundColor(Color("Text1"))
                                        .fontWeight(.black)
                                     

                                }
//                                    .position(x: -35, y: -110)
                                .offset(x: -115, y: -190)
                                    .frame(width: 160.0, height: 160.0)
                                    .onTapGesture {
                                        self.gamePlay4.toggle()
                                    }
                                     .sheet(isPresented: $gamePlay4){
                                        GridChildhood()}
                        
                        
       
                                ZStack{
                                Image("Image5")// get image assset name here

                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .padding()
                                    .scaledToFit()
                                    
                                    
                                    Text("Teenage")
                                        .foregroundColor(Color("Text1"))
                                        .fontWeight(.black)
                                       
                                }
//                                    .position(x: -60, y: -5)
                                .offset(x: -140, y: -85)
                                    .frame(width: 160.0, height: 160.0)
                                    .onTapGesture {
                                        self.gamePlay5.toggle()
                                    }
                                     .sheet(isPresented: $gamePlay5){
                                        GridTeenage()}
        
                        
                                ZStack{
                                Image("Image7")// get image assset name here

                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .padding()
                                    .scaledToFit()
                                    
                                    
                                    Text("Birth")
                                        .foregroundColor(Color("Text1"))
                                        .fontWeight(.black)
                                       
                                }
//                                .position(x: -45, y: 100)
                                .offset(x: -125, y: 20)
                                    .frame(width: 160.0, height: 160.0)
                                    .onTapGesture {
                                        self.gamePlay6.toggle()
                                    }
                                     .sheet(isPresented: $gamePlay6){
                                        GridBirth()}
      
                            }
              
                   

                    
                    }

            
            

            }
        }

      

struct Clouds_Previews: PreviewProvider {
    @State static  var game = false
    static var previews: some View {
        Clouds(gamePlay: $game, gamePlay1: $game, gamePlay2: $game, gamePlay3: $game, gamePlay4: $game, gamePlay5: $game, gamePlay6: $game)
    }
}
