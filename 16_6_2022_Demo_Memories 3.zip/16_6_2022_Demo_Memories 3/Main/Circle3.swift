//
//  Circle3.swift
//  Memories
//
//  Created by Erika Sito on 30/05/22.
//

import SwiftUI

struct Circle3: View {
    var body: some View {
        Circle()
            .inset(by: 15)
            .stroke(Color(UIColor(named: "Text1")!), style: StrokeStyle(lineWidth: 1, dash: [5]))
//            .scaledToFit()
            .padding()
//            .offset(x: 0, y: -50)
          
            .frame(width: 380, height: 380)
    }
}

struct Circle3_Previews: PreviewProvider {
    static var previews: some View {
        Circle3()
    }
}
