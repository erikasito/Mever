//
//  Carousel.swift
//  Memories
//
//  Created by Erika Sito on 31/05/22.
//

import SwiftUI

struct Carousel: View {
    
    @AppStorage("Write your dreams") private var text2 = "Write your dreams"
    @AppStorage("onboarding") var onboarding = false
    
//    @State var closeOnboarding = false

    @State var gamePlay = false
    @State var gamePlay1 = false
    @State var gamePlay2 = false
    @State var gamePlay3 = false
    @State var gamePlay4 = false
    @State var gamePlay5 = false
    @State var gamePlay6 = false
    
    private func getScale(proxy: GeometryProxy) -> CGFloat {
        var scale: CGFloat = 1.0
        
        let x = proxy.frame(in: .global).minX
        
        let diff = abs(x - 32)
            if diff < 100 {
            scale = 1 + (100 - diff) / 500
            
        }
            
            
            
        return scale
    }
    
    var body: some View {
        
    
    NavigationView{
        
        
        ZStack{
            
            Color(UIColor(named: "BackgroundColor")!)
                               .edgesIgnoringSafeArea(.all)
           
//            Button("Onboarding"){
//                onboarding.toggle()
//            }.accentColor(Color(UIColor(named: "Text1")!))
//                .offset(x: -140, y: -440)
//                .frame(width: 90, height: 5)
            
            VStack{
                
               
                
                
                Rectangle()
                .fill(Color(UIColor(named: "BackgroundColor4")!))
                    .frame(width:415, height: 70)

                    .overlay(
                        Text("Messages to the World")
                            .font(.largeTitle)
                            .fontWeight(.bold)
                            .foregroundColor(Color(UIColor(named: "Text1")!))
                            .offset(x: 0, y: -0)
                            .background(Color(UIColor(named: "BackgroundColor4")!))
                                                  .padding(.all, 10)
//                                                  .background(Color(.systemGray6))
                                                  .cornerRadius(8)
                                                  .foregroundColor(Color(UIColor(named: "Text2")!))
//                        .font(.largeTitle)
//                        .fontWeight(.bold)
//                        .padding()
                     
                    )
            
            

            }.multilineTextAlignment(.center)
                .font(.largeTitle)
                .offset(x: 0, y: 10)
        
            
        VStack{
            
            ZStack{
                                                        Circle3()
                                                            .offset(x: 0, y: -70)
                Clouds(gamePlay: $gamePlay, gamePlay1: $gamePlay1, gamePlay2: $gamePlay2, gamePlay3: $gamePlay3, gamePlay4: $gamePlay4, gamePlay5: $gamePlay5, gamePlay6: $gamePlay6)
                    .offset(x: 0, y: 10)
                
            Name_Surname()
                    .offset(x: 0, y: 110)
                    
            CircleImage(image: Image("Erika"))
                    .offset(x: 0, y: -65)
            }

            
            
            VStack{
                
            
           
        ScrollView{
         
        
            
            
            ScrollView(.horizontal, showsIndicators: false){
               
                HStack(alignment: .top, spacing: 50){
                ForEach(aboutmessage) { num in
                    GeometryReader{ proxy in
                       
                        NavigationLink(destination:
                                        MessageDetail(message: num, textmessage: TextMessage(id: 0, description: "")), label: {
                            
                            
                            VStack{
                               
                                
                         let scale = getScale(proxy: proxy)
                            
                            Image(num.imageName)
                                .resizable()
                                .scaledToFill()
                                .frame(width: 150)
                                .cornerRadius(8)
                                .overlay(RoundedRectangle(cornerRadius: 8).stroke(lineWidth: 0.5))

                                .clipped()
                                .cornerRadius(5)
                                .shadow(radius: 5)
                                .scaleEffect(CGSize(width: scale, height: scale))
                                .animation(.easeOut(duration: 0.5))
                                .padding(.vertical)

                                

                                Text(num.title)
                                    .padding(.top)
                                    .multilineTextAlignment(.center)
                                    .foregroundColor(Color(UIColor(named: "Text1")!))
                                    .font(.system(size: 25, weight: .bold))
                                
                                
//                                Rectangle()
//                                .fill(Color(UIColor(named: "BackgroundColor")!))
//                                    .frame(width:420, height: 70)
//
//                                    .overlay(
//                                        TextField("Write your dremas", text: $text2)
//                                                                  .padding(.all, 10)
//
//                                                                  .cornerRadius(8)
//
//                                                                  .foregroundColor(Color(.systemGray))
//                                    )
        
                        }
                           
                        })
                        
                    }

                        .frame(width: 125, height: 290)
                }
                }.padding(.horizontal, 32)
                    .padding(.vertical, 32)
            }
            Spacer()
                .frame(width: 16)
                
        }
            
        .background(Color(UIColor(named: "BackgroundColor4")!))
//        .navigationTitle(Text("Message to the world")
//                .font(.system(size: 1000))
//            )

            
            
//            .navigationBarTitle(Text("Dashboard").font(.subheadline), displayMode: .large)
        }
        
           
            
        }
            
    }  .navigationBarItems(
        trailing: NavigationLink(destination: {
            SettingsView()
        }, label: {
            Image(systemName: "person.crop.circle")
                .font(.system (size: 30))
                .foregroundColor(Color(UIColor(named: "Text1")!))//                        .resizable()
//                        .padding()
    
                
        })
    )
        
    }

    }
}

struct Carousel_Previews: PreviewProvider {
    @State static  var close = false

    static var previews: some View {
        Carousel(onboarding: close)
    }
}
