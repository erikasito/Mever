//
//  prova.swift
//  Demo_Memories
//
//  Created by Erika Sito on 16/06/22.
//

import SwiftUI

struct prova: View {
    
    @AppStorage("Write your dreams") private var text2 = "Write your dreams"

    var body: some View {
        
        Rectangle()
        .fill(Color(UIColor(named: "BackgroundColor4")!))
            .frame(width:420, height: 70)

            .overlay(
                TextField("Name - Surname", text: $text2)
                                          .padding(.all, 10)

                                          .cornerRadius(8)

                                          .foregroundColor(Color(.systemGray))
            )
    }
}

struct prova_Previews: PreviewProvider {
    static var previews: some View {
        prova()
    }
}
