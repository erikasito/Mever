//
//  Circle2.swift
//  Memories
//
//  Created by Erika Sito on 30/05/22.
//

import SwiftUI

struct Circle2: View {
    var body: some View {
        NavigationView {
            
            ZStack{
                
//                Circle3()
                
                ZStack{
                    
                    NavigationLink(destination: GridBirth(), label: {
                        ZStack{
//                            RoundedRectangle(cornerRadius: 30)
//                                        .frame(height: 1000)
//                                        .padding()
                                
                        Image("Image1")
                            .resizable()
                            .padding()
                            .scaledToFit()
                            .frame(width: 150.0, height: 150.0)
                        
                        Text("Adult")
                            .foregroundColor(Color("Text1"))
                            .fontWeight(.bold)
                            .frame(width: 70, height: 70.0)
    //                        .offset(x: -83, y: -200)
                        }

                    })
                    .offset(x: 0, y: -200)
                    
    //                NavigationLink(destination: Grid()) {
    //                    Image("Image1")
    //                        .resizable()
    //                        .padding()
    //                        .scaledToFit()
    //                        .offset(x: 36, y: -200)
    //                        .frame(width: 150.0, height: 150.0)
    //
    //                    Text("Adult")
    //                        .foregroundColor(Color("Text1"))
    //                        .fontWeight(.bold)
    //                        .frame(width: 70, height: 70.0)
    //                        .offset(x: -83, y: -200)
    //                }
                    
    //            }
                
                //      cloud right
                
                Image("cloud")
                    .resizable()
                    .padding()
                    .scaledToFit()
                    .frame(width: 400.0, height: 400.0)
                    .offset(x: 120, y: -90)
                
                Text("Midlife")
                    .foregroundColor(Color("Text1"))
                    .fontWeight(.bold)
                    .multilineTextAlignment(.center)
                    .frame(width: 70, height: 70.0)
                    .offset(x: 112, y: -168)
                
                
                
                ZStack{
                    
                    Image("cloud")
                        .resizable()
                        .padding()
                        .scaledToFit()
                        .frame(width: 400.0, height: 400.0)
                        .offset(x: 160, y: 5)
                    
                    Text("Seniority")
                        .foregroundColor(Color("Text1"))
                        .fontWeight(.bold)
                        .frame(width: 75, height: 75)
                        .offset(x: 152, y: -74)
                    
                    Image("cloud")
                        .resizable()
                        .padding()
                        .scaledToFit()
                        .frame(width: 400.0, height: 400.0)
                        .offset(x: 155, y: 110)
                    
                    
                    Text("???")
                        .foregroundColor(Color("Text1"))
                        .fontWeight(.bold)
                        .frame(width: 70, height: 70.0)
                        .offset(x: 148, y: 35)
                }
                
                //      cloud left
                
                ZStack{
                    
                    Image("cloud")
                        .resizable()
                        .padding()
                        .scaledToFit()
                        .frame(width: 400.0, height: 400.0)
                        .offset(x: -95, y: -85)
                    
                    Text("Teenage")
                        .foregroundColor(Color("Text1"))
                        .fontWeight(.bold)
                        .frame(width: 70, height: 70.0)
                        .offset(x: -103, y: -163)
                    
                    
                    
                    Image("cloud")
                        .resizable()
                        .padding()
                        .scaledToFit()
                        .frame(width: 400.0, height: 400.0)
                        .offset(x: -140, y: 5)
                    
                    Text("Childhood")
                        .foregroundColor(Color("Text1"))
                        .fontWeight(.bold)
                        .frame(width: 100.0, height: 100.0)
                        .offset(x: -150, y: -73)
                    
                    
                    Image("cloud")
                        .resizable()
                        .padding()
                        .scaledToFit()
                        .frame(width: 400.0, height: 400.0)
                        .offset(x: -135, y: 105)
                    
                    Text("Birth")
                        .foregroundColor(Color("Text1"))
                        .fontWeight(.bold)
                        .frame(width: 70, height: 70.0)
                        .offset(x: -145, y: 27)
            
                }
                }
            }
//            .offset(x: 0, y: -55)
        }
        //        .position(x: 207, y: 150)
    }
}



struct Circle2_Previews: PreviewProvider {
    static var previews: some View {
        Circle2()
    }
}
