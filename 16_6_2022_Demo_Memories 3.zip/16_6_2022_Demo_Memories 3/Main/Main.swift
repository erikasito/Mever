//
//  Main.swift
//  Demo_Memories
//
//  Created by Erika Sito on 15/06/22.
//

import SwiftUI

struct Main: View {
  
    @AppStorage("onboarding") var onboarding = false
//    @State static  var close = false
    @Binding var close: Bool
    
    var body: some View {
        VStack{
        if onboarding {
            onBoardingOk(closeOnboarding: $close)
        }else{
            Carousel()
//                .transition(.move(edge: .trailing))
                .transition(.opacity.animation(.default))
                
        }
        }
//        .animation(.default)
    }
}

struct Main_Previews: PreviewProvider {
    @State static  var close = false
    static var previews: some View {
        Main(close: $close)
    }
}
