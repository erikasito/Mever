//
//  prova2.swift
//  Demo_Memories
//
//  Created by Erika Sito on 14/06/22.
//

import SwiftUI

struct Name_Surname: View {
    
    @AppStorage("name_surname") private var text1 = ""
    
    var body: some View {
        ZStack{
            HStack{
                Rectangle()
                .fill(Color(UIColor(named: "BackgroundColor")!))
                    .frame(width:420, height: 70)

                    .overlay(
                        TextField("Name - Surname", text: $text1)
                            .accessibilityElement(children: /*@START_MENU_TOKEN@*/.contain/*@END_MENU_TOKEN@*/)
                        
                                  .padding(.all, 10)

                                                  .cornerRadius(8)

                                                  .foregroundColor(Color(UIColor(named: "Text1")!))
                                                                    .accessibilityLabel(/*@START_MENU_TOKEN@*/"Label"/*@END_MENU_TOKEN@*/)
                                                  
                    )
            
            

            }.multilineTextAlignment(.center)
                .font(.largeTitle)
                
            
            }
        
    }
}

struct Name_Surname_Previews: PreviewProvider {
    static var previews: some View {
        Name_Surname()
            .previewDevice("iPhone 11")
    }
}
