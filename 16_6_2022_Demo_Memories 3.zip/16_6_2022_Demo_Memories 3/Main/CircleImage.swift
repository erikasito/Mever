//
//  CircleImage.swift
//  Memories
//
//  Created by Erika Sito on 30/05/22.
//

import SwiftUI

struct CircleImage: View {
    var image: Image
    var body: some View {
        ZStack{
        image
            .resizable()
            .scaledToFit()
            .clipShape(Circle())
            .overlay(Circle().stroke( Color(UIColor(named: "BackgroundColor3")!), lineWidth: 5))
            .padding()
            .frame(width: 180, height: 180)
            
    }
}
}
struct CircleImage_Previews: PreviewProvider {
    static var previews: some View {
        CircleImage(image: Image("Erika"))
    }
}

